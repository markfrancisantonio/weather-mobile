export function formatTemp(value) {
  return Math.round(value * 10) / 10;
}
